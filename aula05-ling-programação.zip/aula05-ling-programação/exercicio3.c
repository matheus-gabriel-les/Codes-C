#include <stdio.h>

void copiaString(char destino[], char origem[]) {
    int i = 0;
    while (origem[i] != '\0') {
        destino[i] = origem[i];
        i++;
    }
    destino[i] = '\0';
}

void calcula_media(float notas[5][4], int tamanho, char alunos[5][30], float media[5], 
                   float *maior, float *menor, char alunoMaior[30], char alunoMenor[30]) 
{
    float soma = 0;

   
    for (int j = 0; j < tamanho; j++) {
        soma += notas[0][j];
    }
    media[0] = soma / tamanho;

    *maior = media[0];
    *menor = media[0];

    copiaString(alunoMaior, alunos[0]);
    copiaString(alunoMenor, alunos[0]);

    
    for (int i = 1; i < 5; i++) {
        soma = 0;
        for (int j = 0; j < tamanho; j++) {
            soma += notas[i][j];
        }
        media[i] = soma / tamanho;

        if (media[i] > *maior) {
            *maior = media[i];
            copiaString(alunoMaior, alunos[i]); 
        } 
        else if (media[i] < *menor) {
            *menor = media[i];
            copiaString(alunoMenor, alunos[i]); 
        }
    }
}

int main() {
    char alunos[5][30];
    float notas[5][4];
    float media[5];
    float maior, menor;
    char alunoMaior[30], alunoMenor[30];

    int tamanho = 4;


    for (int i = 0; i < 5; i++) {
        printf("Digite o nome do aluno: ");
        scanf("%s", alunos[i]);

        for (int j = 0; j < tamanho; j++) {
            printf("Digite a nota do B%d: ", j + 1);
            scanf("%f", &notas[i][j]);
        }
        printf("\n");
    }

    calcula_media(notas, tamanho, alunos, media, &maior, &menor, alunoMaior, alunoMenor);


    printf("\n=== Tabelas Alunos e Bimestres ===\n");
    printf("Aluno\tB1\tB2\tB3\tB4\tMedia\tSituacao\n");

    for (int i = 0; i < 5; i++) {
        printf("%s\t", alunos[i]);

        for (int j = 0; j < tamanho; j++) {
            printf("%.1f\t", notas[i][j]);
        }

        printf("%.1f\t", media[i]);

        if (media[i] >= 7.0) {
            printf("Aprovado\n");
        } 
        else if (media[i] >= 5.0 && media[i] < 7.0) { 
            printf("Recuperacao\n");
        } 
        else {
            printf("Reprovado\n");
        }
    }

    printf("\nAluno com a maior media: %s (%.1f)\n", alunoMaior, maior);
    printf("Aluno com a menor media: %s (%.1f)\n", alunoMenor, menor);

    return 0;
}
