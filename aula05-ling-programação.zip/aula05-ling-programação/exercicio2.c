
#include <stdio.h>


void calcula_numeros(int *array,int tamanho,int *par,int *imp,int *mult){
  
  int *fim = array + tamanho;
   *par = 0;
   *imp = 0;
   *mult = 0;

   for(int *p = array; p < fim;p++){

   if(*p % 3 == 0 && *p % 5 == 0 ){
         (*mult)++;
      }
    else{
         if( *p % 2 == 0 && *p > 0){
          (*par)++;
      }
      else{
        if(!(*p % 2 == 0) || *p < 0){
        (*imp)++;
        }
      }
    }
        
  }
}



int main(){

   int numeros[10];
   int tamanho = sizeof(numeros) / sizeof(numeros[0]);
   int par,imp,mult;

     for(int i = 0; i < tamanho;i++){
        printf("Digite um numero");
        scanf("%d",&numeros[i]);
     }

    calcula_numeros(numeros,tamanho,&par,&imp,&mult);
    
    printf("Quantidade de numeros pares e positivos:%d\n",par);
    printf("Quantidade de numeros impares ou negativos:%d\n",imp);
    printf("Quantidade de numeros multiplos de 3 e de 5:%d\n",mult);
    
    return 0;
}