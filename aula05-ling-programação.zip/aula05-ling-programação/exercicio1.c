
#include <stdio.h>

void calcula_desconto(int *array,int tamanho,float *descontos){
   
   int *p = array;//recebe o array no inicio
   float *q = descontos;
   int *fim = array + tamanho;//rcebe o fim do array
 
   for(int i = 0 ; p < fim ;i++,p++,q++){// for para preencher descontos

       if(*p >= 100){

         *q = *p * 0.9;
       }
       else if(*p >= 50 && *p < 100 ){
          
           *q = *p * 0.95;
       }
       else{
          *q = *p;
       }
   }
    
}
int main(){

     int numeros[5];
     int tamanho = sizeof(numeros) / sizeof(numeros[0]);
     float descontos[5];//difine um array que armazena os valores descontados

     for(int i = 0; i < tamanho;i++){
        printf("Digite um numero");
        scanf("%d",&numeros[i]);
     }

    calcula_desconto(numeros,tamanho,descontos);

    for(int i = 0; i < tamanho;i++){
       printf("Valor original:%d\n",numeros[i]);

        if(numeros[i] >= 100)
        {        
           printf("Valor do desconto: 10%%\n");
          printf("Valor com desconto:%.2f\n",descontos[i]);
        }
        else if( numeros[i] >= 50 && numeros[i] < 100){
          printf("Valor do desconto: 5%%\n");
          printf("Valor com desconto:%.2f\n",descontos[i]);
        }
        else{
           printf(" O produto nao tem desconto!\n");
           printf("Valor Final:%.2f\n",descontos[i]);
        }
    }  

    return 0;
}    
