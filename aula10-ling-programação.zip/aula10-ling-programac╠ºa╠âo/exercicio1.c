
#include <stdio.h>
#include <stdlib.h>

int *verifica_memoria(int qtd){

  int *vet = (int *) malloc(qtd * sizeof(int));

   if( vet == NULL){
      printf("Erro na alocacao!");
      exit(1);
   }
   return vet;
}

void solicitar_numero(int **numeros,int *qtd){
   
   printf("Quantos numeros deseja digitar?  ");
   scanf("%d",qtd);

   *numeros = verifica_memoria(*qtd);
   
   for(int i = 0; i < *qtd; i++){   
     printf("Digite um numero:  ");
     scanf("%d",&((*numeros)[i]));
   }
}

int main(){
    
    int *numeros;
    int qtd;
   
   solicitar_numero(&numeros,&qtd);

   printf("Numeros pares: ");
   for(int i = 0; i < qtd; i++)
     if(numeros[i] % 2 == 0 ){
        printf("%d",numeros[i]);
        printf(" ");
    }
    printf("\n");

    free(numeros);

    return 0;
}