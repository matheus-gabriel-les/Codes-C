#include <stdio.h>
#include <stdlib.h>
#include <string.h>


char **tamanho_lista(int n) {
    char **lista = (char **) malloc(n * sizeof(char *));
    if (lista == NULL) {
        printf("Erro na alocacao!\n");
        exit(1);
    }
    return lista;
}


char **aumentar_lista(char **lista, int n) {
    char **nova_lista = (char **) realloc(lista, n * sizeof(char *));
    if (nova_lista == NULL) {
        printf("Erro ao realocar memoria!\n");
        exit(1);
    }
    return nova_lista;
}

int main() {
    int tamanho = 2;
    int opcao;
    char **lista = tamanho_lista(tamanho);


    lista[0] = strdup("batata");
    lista[1] = strdup("feijao");

    while (1) {
        printf("Escolha uma opcao: 1-adicionar um produto, 2-fechar compra: ");
        scanf("%d", &opcao);
        getchar(); 

        if (opcao < 1 || opcao > 2) {
            printf("Numero invalido. Digite novamente.\n");
        } else {
            switch (opcao) {
                case 1: {
                    tamanho++;
                    lista = aumentar_lista(lista, tamanho);

                    char buffer[100];
                    printf("Digite o nome do produto: ");
                    fgets(buffer, sizeof(buffer), stdin);
                    buffer[strcspn(buffer, "\n")] = '\0';
                    lista[tamanho - 1] = strdup(buffer);
                    break;
                }
                case 2: {
                    printf("\nCompra fechada!\n");
                    printf("Lista de produtos:\n");
                    for (int i = 0; i < tamanho; i++) {
                        printf("%d. %s\n", i + 1, lista[i]);
                        free(lista[i]);
                    }
                    free(lista);
                    return 0;
                }
            }
        }
    }

    return 0;
}
