
#include <stdio.h>
#include <stdlib.h>


int *tamanho_vet1(int n){
     int *vet1 = (int *) malloc( n * sizeof(int));
      if( vet1 == NULL){
      printf("Erro na alocacao!");
      exit(1);
   }
   return vet1;
}
int *tamanho_vet2(int n){
     int *vet2 = (int *) malloc(n * sizeof(int));
     if( vet2 == NULL){
      printf("Erro na alocacao!");
      exit(1);
   }
   return vet2;
}
int *tamanho_vet3(int n){
     int *vet3 = (int *) malloc(n * sizeof(int));
     if( vet3 == NULL){
      printf("Erro na alocacao!");
      exit(1);
   }
   return vet3;
}
void preenche_vetor(int *vet1,int *vet2,int tam1, int tam2){

   for(int i = 0 ; i < tam1;i++){
        printf("Digite um numero:  ");
        scanf("%d",&vet1[i]);
   }
   for(int i = 0 ; i < tam2; i++){
        printf("Digite um numero:  ");
        scanf("%d",&vet2[i]);
   }
}

void concatena_vetor(int *vet1,int *vet2,int *vet3,int tam1, int tam2){
    for(int i = 0; i < tam1; i++){ 
        vet3[i] = vet1[i];
    }
     for(int i = 0; i < tam2; i++){ 
        vet3[tam1 + i] = vet2[i];
    }
}
int main(){
     int tam1 = 5,tam2 = 6;
     int  tam3 = tam1 + tam2;
     int *vet1 = tamanho_vet1(tam1);
     int *vet2 = tamanho_vet2(tam2);
     int *vet3 = tamanho_vet3(tam3);

     preenche_vetor(vet1,vet2,tam1,tam2);
     concatena_vetor(vet1,vet2,vet3,tam1,tam2);

    printf("Vetor concatenado: ");
    for (int i = 0; i < tam1 + tam2; i++) {
        printf("%d ", vet3[i]);
    }
    printf("\n");


     free(vet1);
     free(vet2);
     free(vet3);


     return 0;
}