#include <stdio.h>

int main(){

    float salario = 2500.50;
    float *ponteiro_salario;

    ponteiro_salario = &salario;
    printf("Valor inicial do salario:%.2f \n",*ponteiro_salario);

    *ponteiro_salario = 3000.00;
    printf("Valor modificado pelo ponteiro:%.2f \n",*ponteiro_salario);

    return 0;

}