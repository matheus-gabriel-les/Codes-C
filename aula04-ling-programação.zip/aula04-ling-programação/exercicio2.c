#include <stdio.h>


void calcular_retangulo(float largura,float altura,float *area,float *perimetro){
 
   *area = largura * altura;
   *perimetro = 2 * altura + 2 * largura;
   
    
}

int main(){

    float l = 5.0,h = 3.0;
    float area,perimetro;

    calcular_retangulo(l,h,&area,&perimetro);

    printf("Retangulo %.1f x %1.f\n",l,h);
    printf("Area: %.2f\n",area);
    printf("Perimetro: %.2f\n",perimetro);

}