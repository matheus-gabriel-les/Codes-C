#include <stdio.h>
#include <string.h>

void inverter_string(char *str){
    
    char *comeco = str;
    char *fim = str + strlen(str) - 1;
    
    while (comeco < fim)
    {
        char temp = *comeco;
        *comeco = *fim;
        *fim = temp;

        comeco++;
        fim--;
    }
    
    
}

int main(){

     char texto[] = "PONTEIROS";

     printf("String original: %s\n",texto);
     inverter_string(texto);
     printf("String invertida: %s\n",texto);

     return 0;

}