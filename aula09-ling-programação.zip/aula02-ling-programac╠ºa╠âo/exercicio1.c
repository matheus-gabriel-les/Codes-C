#include <stdio.h>

void mostrar_resultado(float resultado) {
    printf("O resultado da operação é: %.2f\n", resultado);
}

float celsiusParaFahrenheit(float celsius) {
    return (celsius * 9 / 5) + 32;
}

float fahrenheitParaCelsius(float fahrenheit) {
    return (fahrenheit - 32) * 5 / 9;
}

float celsiusParaKelvin(float celsius) {
    return celsius + 273.15;
}

float kelvinParaCelsius(float kelvin) {
    return kelvin - 273.15;
}

float fahrenheitParaKelvin(float fahrenheit) {
    float celsius = fahrenheitParaCelsius(fahrenheit);
    return celsiusParaKelvin(celsius);
}

float kelvinParaFahrenheit(float kelvin) {
    float celsius = kelvinParaCelsius(kelvin);
    return celsiusParaFahrenheit(celsius);
}

void mostrar_opcao() {
    int operacao;
    float valor, resultado;

    do {
        printf("\n=== CONVERSOR DE TEMPERATURAS ===\n");
        printf("1 - Celsius para Fahrenheit\n");
        printf("2 - Fahrenheit para Celsius\n");
        printf("3 - Celsius para Kelvin\n");
        printf("4 - Kelvin para Celsius\n");
        printf("5 - Fahrenheit para Kelvin\n");
        printf("6 - Kelvin para Fahrenheit\n");
        printf("0 - Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &operacao);

        if (operacao == 0) {
            printf("Encerrando o programa...\n");
            break;
        }

        if (operacao < 1 || operacao > 6) {
            printf("Opção inválida. Tente novamente.\n");
            continue;
        }

        printf("Digite o valor da temperatura: ");
        scanf("%f", &valor);

        switch (operacao) {
            case 1:
                resultado = celsiusParaFahrenheit(valor);
                break;
            case 2:
                resultado = fahrenheitParaCelsius(valor);
                break;
            case 3:
                resultado = celsiusParaKelvin(valor);
                break;
            case 4:
                resultado = kelvinParaCelsius(valor);
                break;
            case 5:
                resultado = fahrenheitParaKelvin(valor);
                break;
            case 6:
                resultado = kelvinParaFahrenheit(valor);
                break;
            default:
                printf("Erro inesperado.\n");
                continue;
        }

        mostrar_resultado(resultado);

    } while (1);
}

int main() {
    mostrar_opcao();
    return 0;
}
