#include <stdio.h>

float calcularDesconto(float valorCompra){
    
    float percentual = 0.0;

     if(valorCompra < 100){
       percentual = 0.0;
   }
   else if(valorCompra >= 100 && valorCompra < 500){
       percentual = 5.0;
   }
   else{
      if(valorCompra >= 500 && valorCompra < 1000){
        percentual = 10.0;
      }
      else if(valorCompra >= 1000){
         percentual = 15.0;
      }
   }
  return valorCompra * (percentual / 100);
    
}
float aplicarDesconto(float valorCompra, float percentual){
  
    float valorDesconto = valorCompra * (percentual / 100);
    return valorCompra - valorDesconto;
}
float calcularValorFinal(float valorCompra){

    float valorDesconto = calcularDesconto(valorCompra);
    float valorFinal = aplicarDesconto(valorCompra, valorDesconto);

    printf("\n--- RESUMO DA COMPRA ---\n");
    printf("Valor original: R$ %.2f\n", valorCompra);
    printf("Desconto: R$ %.2f\n", valorDesconto);
    printf("Valor final: R$ %.2f\n", valorFinal);

    return valorFinal;
}

void exibirResumo(float valorOriginal, float percentualDesconto, float valorDesconto, float valorFinal) {
    printf("\n--- RESUMO DA COMPRA ---\n");
    printf("Valor original: R$ %.2f\n", valorOriginal);
    printf("Percentual de desconto: %.1f%%\n", percentualDesconto);
    printf("Valor do desconto: R$ %.2f\n", valorDesconto);
    printf("Valor final: R$ %.2f\n", valorFinal);
}


int main(){
    float valorCompra, percentual, valorDesconto, valorFinal;

    printf("Digite o valor total da compra: ");
    scanf("%f", &valorCompra); 

    percentual = calcularDesconto(valorCompra);
    valorDesconto = valorCompra * (percentual / 100);
    valorFinal = aplicarDesconto(valorCompra, percentual);

    exibirResumo(valorCompra, percentual, valorDesconto, valorFinal);

    return 0;

}