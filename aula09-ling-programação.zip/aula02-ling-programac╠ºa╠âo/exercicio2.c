#include <stdio.h>
#include <math.h>

float calcularIMC(float peso, float altura){

    float IMC = peso / (altura * altura);

    return IMC;
}
void exibirClassificacao(float IMC){
   if(IMC >= 18.5 && IMC < 25.0){
      printf("Peso normal");
   }
   else if(IMC >= 25.0 && IMC < 30.0){
      printf("Sobrepeso");
   }
   else{
      if(IMC >= 30.0 && IMC < 35.0){
        printf("Obesidade Grau I");
      }
      else if(IMC >= 35.0 && IMC < 40.0){
        printf("Obesidade Grau II");
      }
      else{
         printf("Obesidade Grau III");
      }
   }

}
  void calcularPesoIdeal(float altura){
     float peso = pow(altura,2) * 22;
     printf("O peso ideal deve ser: %.2f",peso);
  }


 float validarDados(float peso, float altura){
   if(peso > 0 && altura > 0){
      return 1;
   }else{
      printf("Erro: Peso e altura devem ser maiores que zero.\n");
      return 0;
   }
}

int main(){
    float peso,altura;

    printf("Digite um peso  ");
    scanf("%f",&peso);
    printf("Digite uma altura ");
    scanf("%f",&altura);

    validarDados(peso,altura);
    float IMC = calcularIMC(peso, altura);
    exibirClassificacao(IMC);
    calcularPesoIdeal(altura);
    return 0;
}